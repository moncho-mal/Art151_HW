function setup() {
  createCanvas(windowWidth, windowHeight);
  background(220, 210, 228);
}

function draw() {
  noStroke();

  fill(209, 140, 245, 150);
  ellipse(windowWidth / 1, windowHeight / 3,   925, 4);
  ellipse(windowWidth / 1, windowHeight / 3.2, 825, 4);
  ellipse(windowWidth / 1, windowHeight / 3.4, 725, 4);
  ellipse(windowWidth / 1, windowHeight / 3.8, 625, 4);
  ellipse(windowWidth / 1, windowHeight / 4.0, 525, 4);
  ellipse(windowWidth / 1, windowHeight / 4.2, 425, 4);
  ellipse(windowWidth / 1, windowHeight / 4.4, 325, 4);
  ellipse(windowWidth / 1, windowHeight / 4.6, 225, 4);
  ellipse(windowWidth / 1, windowHeight / 4.8, 325, 4);
  ellipse(windowWidth / 1, windowHeight / 5.0, 425, 4);
  ellipse(windowWidth / 1, windowHeight / 5.2, 525, 4);
  ellipse(windowWidth / 1, windowHeight / 5.4, 625, 4);
  ellipse(windowWidth / 1, windowHeight / 5.6, 725, 4);
  ellipse(windowWidth / 1, windowHeight / 5.8, 825, 4);
 
  fill(242, 92, 138, 150);
  ellipse(windowWidth / 1, windowHeight / 3,   225, 4);
  ellipse(windowWidth / 1, windowHeight / 3.2, 325, 4);
  ellipse(windowWidth / 1, windowHeight / 3.4, 425, 4);
  ellipse(windowWidth / 1, windowHeight / 3.8, 525, 4);
  ellipse(windowWidth / 1, windowHeight / 4.0, 625, 4);
  ellipse(windowWidth / 1, windowHeight / 4.2, 725, 4);
  ellipse(windowWidth / 1, windowHeight / 4.4, 825, 4);
  ellipse(windowWidth / 1, windowHeight / 4.6, 925, 4);
  ellipse(windowWidth / 1, windowHeight / 4.8, 825, 4);
  ellipse(windowWidth / 1, windowHeight / 5.0, 725, 4);
  ellipse(windowWidth / 1, windowHeight / 5.2, 625, 4);
  ellipse(windowWidth / 1, windowHeight / 5.4, 525, 4);
  ellipse(windowWidth / 1, windowHeight / 5.6, 425, 4);
  ellipse(windowWidth / 1, windowHeight / 5.8, 325, 4);

  fill(224, 29, 91, 150);
  
  circle(windowWidth / 2, windowHeight / 1.3 - 10, 475);
  fill(255, 112, 35, 150);
  circle(windowWidth / 2, windowHeight / 1 - 200, 200);
  fill( 245, 166, 129)
  circle(windowWidth / 2, windowHeight / 1 - 300, 200);
  fill(255, 112, 35, 150);
  circle(windowWidth / 2, windowHeight / 1 - 400, 200);
  
  fill(178, 192, 217 );
  arc(91,275,430, 44,20, PI / 120.0);
  fill(255, 195, 0 );
  93, 96, 100 
  circle(windowWidth / 10, windowHeight / 5 - 10, 295);
  
  stroke(10000);
 
  line(0,0, windowWidth / 4.8, windowHeight / 4.8);
  line(2,1, windowWidth / 5.8, windowHeight / 5.8);
  
  function keyTyped() {
  if (key === 's') {
    save("lilsunsetthing.png");
  }
}
  
  
  

  
  
  
  
  
  
  
}